# CODIQ persistent accounts

This project now includes username/password authentication and persistent
assessment history backed by Neon Postgres.

## Setup

1. In Neon SQL Editor, run `db/schema.sql`.
2. Make sure Vercel has `DATABASE_URL` configured for the project.
3. From the project root run:

```bash
npm install
npm run build
```

4. Commit and push the project to the GitHub repository connected to Vercel.

### Security

Passwords are hashed with bcrypt and never stored as plain text.
Sessions use an HTTP-only cookie and expire after 30 days.

Do not commit `.env.local`, database URLs, passwords, or API keys.
