import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { createSession } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();
    const clean = String(username ?? "").trim().toLowerCase();
    const pass = String(password ?? "");

    if (!/^[a-z0-9_]{3,20}$/.test(clean)) {
      return NextResponse.json({ error: "Username must be 3–20 characters using letters, numbers, or underscores." }, { status: 400 });
    }
    if (pass.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    }

    const db = getDb();
    const existing = await db`SELECT id FROM users WHERE username = ${clean} LIMIT 1`;
    if (existing.length) {
      return NextResponse.json({ error: "That username is already taken." }, { status: 409 });
    }

    const hash = await bcrypt.hash(pass, 12);
    const rows = await db`
      INSERT INTO users (username, password_hash)
      VALUES (${clean}, ${hash})
      RETURNING id, username, created_at
    `;
    await createSession(rows[0].id);

    return NextResponse.json({ user: rows[0] });
  } catch {
    return NextResponse.json({ error: "Unable to create account." }, { status: 500 });
  }
}
