import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { createSession } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();
    const clean = String(username ?? "").trim().toLowerCase();
    const pass = String(password ?? "");
    const db = getDb();
    const rows = await db`SELECT id, username, password_hash, created_at FROM users WHERE username = ${clean} LIMIT 1`;

    if (!rows.length || !(await bcrypt.compare(pass, rows[0].password_hash))) {
      return NextResponse.json({ error: "Invalid username or password." }, { status: 401 });
    }

    await createSession(rows[0].id);
    return NextResponse.json({ user: { id: rows[0].id, username: rows[0].username, created_at: rows[0].created_at } });
  } catch {
    return NextResponse.json({ error: "Unable to log in." }, { status: 500 });
  }
}
