import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getDb } from "@/lib/db";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ user: null });

    const db = getDb();
    const attempts = await db`
      SELECT date, overall, recruit_score, archetype, scores
      FROM attempts
      WHERE user_id = ${user.id}
      ORDER BY date ASC
    `;

    const mapped = attempts.map((a: any) => ({
      date: new Date(a.date).toISOString(),
      overall: Number(a.overall),
      recruitScore: Number(a.recruit_score),
      archetype: a.archetype,
      scores: a.scores,
    }));

    return NextResponse.json({
      user,
      profile: {
        name: user.username,
        createdAt: new Date(user.created_at).toISOString(),
        attempts: mapped,
        bestOverall: mapped.reduce((m: number, a: any) => Math.max(m, a.overall), 0),
        bestRecruitScore: mapped.reduce((m: number, a: any) => Math.max(m, a.recruitScore), 0),
      }
    });
  } catch {
    return NextResponse.json({ error: "Unable to load profile." }, { status: 500 });
  }
}
