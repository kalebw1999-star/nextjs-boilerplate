import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getDb } from "@/lib/db";

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

    const body = await request.json();
    const overall = Number(body.overall);
    const recruitScore = Number(body.recruitScore);
    const archetype = String(body.archetype ?? "");
    const scores = body.scores;

    if (!Number.isFinite(overall) || !Number.isFinite(recruitScore) || !archetype || !scores) {
      return NextResponse.json({ error: "Invalid assessment." }, { status: 400 });
    }

    const db = getDb();
    await db`
      INSERT INTO attempts (user_id, overall, recruit_score, archetype, scores)
      VALUES (${user.id}, ${overall}, ${recruitScore}, ${archetype}, ${JSON.stringify(scores)})
    `;

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Unable to save assessment." }, { status: 500 });
  }
}
